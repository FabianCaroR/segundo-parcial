function datos(){
    var fecha = parseFloat(document.getElementById('fecha').value);
    var perfil = document.getElementById('perfil').value;
    var nombre = document.getElementById('nombre').value;
    var correo = document.getElementById('correo').value;
    var telefono = parseFloat(document.getElementById('telefono').value);
    var genero = document.getElementById('genero').value;
    var direccion = document.getElementById('direccion').value;

    var edad = 2020 - fecha;

    document.write(edad+"<br/>");
    document.write(perfil+"<br/>");
    document.write(nombre+"<br/>");
    document.write(correo+"<br/>");
    document.write(telefono+"<br/>");
    document.write(genero+"<br/>");
    document.write(direccion+"<br/>");
}

function previewFile() {
    var preview = document.querySelector('img');
    var file    = document.querySelector('input[type=file]').files[0];
    var reader  = new FileReader();
  
    reader.onloadend = function () {
      preview.src = reader.result;
    }
  
    if (file) {
      reader.readAsDataURL(file);
    } else {
      preview.src = "";
    }
  }
